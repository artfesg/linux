#!/bin/bash

#   helloworld, a program for printing "Hello World to standard output
#   Copyright (C) 2009 Klaus Grue
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#   Contact: Klaus Grue, grue@diku.dk, http://www.diku.dk/~grue/
#
#   helloworld is used for illustrating how to distribute a program
#   using Debian packages, RPM, and Cygwin.

./helloworld | grep "Hello World" || exit 1
./helloworld --help | grep "version  Print version information" || exit 1
./helloworld --version | grep "Available under GNU GPL" || exit 1
echo "Test succeeded"
